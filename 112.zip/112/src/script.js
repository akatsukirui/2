
document.write("可怕的世界之寫程式好難")